	<div class="sidebar">
	  <nav class="sidebar-nav">
	    <ul class="nav">
	      <li class="nav-title">Menu</li>
	      <li class="nav-item">
	        <a class="nav-link" href="usuarios.php?ruta=Conf. Usuarios">
	          <i class="nav-icon cui-cog"></i> Conf. Usuarios</a>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link" href="diligencias.php?ruta=Diligencias">
	          <i class="nav-icon cui-people"></i> Clientes</a>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link" href="informes.php?ruta=Informes">
	          <i class="nav-icon cui-file"></i> Informes</a>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link" href="proyectos.php?ruta=Proyectos">
	          <i class="nav-icon cui-file"></i> Programas</a>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link" href="carguemasivo.php?ruta=Cargue Masivo">
	          <i class="nav-icon cui-file"></i> Cargue Masivo</a>
	      </li>
	      <li class="divider"></li>


	  </nav>

	  <button class="sidebar-minimizer brand-minimizer" type="button"></button>
	</div>