<?php
		include "cabecera.php";
?>
		


<?php
		include "pie.php";
?>