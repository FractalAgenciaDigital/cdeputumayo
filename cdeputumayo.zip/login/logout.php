<?php
session_destroy();
?>
<script>
	document.location.href="login.php";
</script>